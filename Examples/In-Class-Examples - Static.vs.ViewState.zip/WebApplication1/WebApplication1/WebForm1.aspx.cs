﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        static int count = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            PreviousPage
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            count = count + 1;
            StaticLabel.Text = "" + count;

            if (this.ViewState["Counter"] == null)
            {
                this.ViewState["Counter"] = 0;
            }

            int stateCount = (int)this.ViewState["Counter"];
            stateCount = stateCount + 1;
            this.ViewState["Counter"] = stateCount;
            ViewStateLabel.Text = this.ViewState["Counter"].ToString();
        }
    }
}